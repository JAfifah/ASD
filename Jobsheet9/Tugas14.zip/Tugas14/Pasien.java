package Tugas14;

public class Pasien {
    String nama;
    int noID;
    char jenisKelamin;
    int umur;

    public Pasien(String nama, int noID, char jenisKelamin, int umur) {
        this.nama = nama;
        this.noID = noID;
        this.jenisKelamin = jenisKelamin;
        this.umur = umur;
    }
}
