class Rekening14 {
    String noRekening;
    String nama;
    String namaIbu;
    String email;

    Rekening14(String a, String b, String c, String d) {
        noRekening = a;
        nama = b;
        namaIbu = c;
        email = d;
    }
}
//Jami'atul Afifah 14