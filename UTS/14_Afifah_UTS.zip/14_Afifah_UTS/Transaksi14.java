class Transaksi14 {
    double saldo;
    double saldoAwal;
    double saldoAkhir;
    String tanggalTransaksi;
    String type;

    Transaksi14(double a, double b, double c, String d, String e) {
        saldo = a;
        saldoAwal = b;
        saldoAkhir = c;
        tanggalTransaksi = d;
        type = e;
    }
}
//Jami'atul Afifah 14